import React from 'react'

const CreatePost = () => {
  return (
    <div>
      Currently Under Progress
    </div>
  )
}

export default CreatePost
