import React from 'react'

const Profile = () => {
  return (
    <div>
      current in under Progress
    </div>
  )
}

export default Profile
