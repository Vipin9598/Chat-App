import React from 'react'

const ConfirmationModal = () => {
  return (
    <div>
      
    </div>
  )
}

export default ConfirmationModal
