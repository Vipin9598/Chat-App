import React from 'react'

const CreatePostModal = () => {
  return (
    <div>
      
    </div>
  )
}

export default CreatePostModal
